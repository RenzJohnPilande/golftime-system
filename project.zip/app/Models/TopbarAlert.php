<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TopbarAlert extends Model
{
    protected $fillable = ['message', 'active'];
}
